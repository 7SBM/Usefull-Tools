using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using BisDll.Model;
using BisDll.Model.MLOD;
using BisDll.Model.ODOL;

namespace P3DDebinarizer
{
    internal class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            string header = "======================\r\n P3DDebinarizer by T_D\r\n (Fixed build - no Console.Clear)\r\n=======================";
            string usage = "Usage:\r\n  Debinarizer.exe                          - opens file dialog\r\n  Debinarizer.exe path/model.p3d           - converts single file\r\n  Debinarizer.exe inputFolder [outputFolder] - converts all p3d in folder";

            Console.WriteLine(header);
            Console.WriteLine(usage);

            try
            {
                switch (args.Length)
                {
                    case 0:
                    {
                        FolderBrowserDialog dlg = new FolderBrowserDialog();
                        dlg.Description = "Select folder with P3D files to convert";
                        if (dlg.ShowDialog() == DialogResult.OK)
                        {
                            string[] files = Directory.GetFiles(dlg.SelectedPath, "*.p3d", SearchOption.TopDirectoryOnly);
                            if (files.Length == 0)
                                Console.WriteLine("No .p3d files found in: " + dlg.SelectedPath);
                            else
                                ConvertFiles(files, null, false);
                        }
                        break;
                    }
                    case 1:
                    {
                        string path = args[0];
                        if (File.Exists(path))
                        {
                            if (Path.GetExtension(path).ToLower() == ".p3d")
                                ConvertFile(Path.GetFullPath(path), null, false);
                            else
                                Console.WriteLine("Error: File does not have .p3d extension: " + path);
                        }
                        else if (Directory.Exists(path))
                        {
                            ConvertFiles(Directory.EnumerateFiles(path, "*.p3d", SearchOption.TopDirectoryOnly).ToArray(), null, false);
                        }
                        else
                        {
                            Console.WriteLine("Error: File or directory not found: " + path);
                            return 1;
                        }
                        break;
                    }
                    case 2:
                    {
                        string src = args[0];
                        string dst = args[1];
                        if (!Directory.Exists(src)) { Console.WriteLine("Error: Source folder not found: " + src); return 1; }
                        if (!Directory.Exists(dst)) { Console.WriteLine("Error: Output folder not found: " + dst); return 1; }
                        ConvertFiles(Directory.EnumerateFiles(src, "*.p3d", SearchOption.TopDirectoryOnly).ToArray(), dst, false);
                        break;
                    }
                    default:
                        Console.WriteLine(usage);
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: " + ex.Message);
                Console.WriteLine(ex.StackTrace);
                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
                return 1;
            }
            Console.WriteLine("\nDone! Press any key to exit...");
            Console.ReadKey();
            return 0;
        }

        private static void ConvertFiles(string[] files, string dstFolder, bool overwrite = false)
        {
            Console.WriteLine("Converting " + files.Length + " file(s)...");
            int failed = 0;
            foreach (string file in files)
            {
                string dst = dstFolder == null ? null : Path.Combine(dstFolder, Path.GetFileName(file));
                if (!ConvertFile(file, dst, overwrite)) failed++;
            }
            if (failed == 0)
                Console.WriteLine("All conversions finished successfully.");
            else
                Console.WriteLine(failed + " conversion(s) failed.");
        }

        private static bool ConvertFile(string srcPath, string dstPath, bool overwrite = false)
        {
            if (!overwrite && srcPath == dstPath)
            {
                Console.WriteLine("Skipping (overwrite disabled): " + srcPath);
                return false;
            }
            Console.WriteLine("Reading: " + srcPath);
            P3D p3d = P3D.GetInstance(srcPath);
            if (p3d is MLOD)
            {
                Console.WriteLine("Already in MLOD (editable) format: " + srcPath);
                return true;
            }
            ODOL odol = p3d as ODOL;
            if (odol != null)
            {
                Console.WriteLine("ODOL loaded. Converting to MLOD...");
                MLOD mlod = Conversion.ODOL2MLOD(odol);
                Console.WriteLine("Conversion successful.");
                string outPath = dstPath ?? Path.Combine(
                    Path.GetDirectoryName(srcPath),
                    Path.GetFileNameWithoutExtension(srcPath) + "_mlod.p3d");
                mlod.writeToFile(outPath, overwrite);
                Console.WriteLine("Saved: " + outPath);
                return true;
            }
            Console.WriteLine("Failed to load (unknown format): " + srcPath);
            return false;
        }
    }
}
