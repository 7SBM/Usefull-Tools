using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BisDll.Stream;

namespace BisDll.Model.ODOL;

public class ODOL : P3D
{
	public const int LATEST_VERSION = 73;

	public const int MINIMAL_VERSION = 28;

	private string muzzleFlash;

	private uint appID;

	private int nLods;

	private float[] resolutions;

	public ODOL_ModelInfo modelInfo;

	private bool hasAnims;

	private Animations animations = new Animations();

	private uint[] lodStartAdresses;

	private uint[] lodEndAdresses;

	private bool[] permanent;

	private List<LoadableLodInfo> LoadableLodInfos;

	private LOD[] lods;

	public Skeleton Skeleton => modelInfo.skeleton;

	public override float Mass => modelInfo.mass;

	public override P3D_LOD[] LODs => lods;

	public ODOL(string fileName)
		: this(File.OpenRead(fileName))
	{
	}

	public ODOL(System.IO.Stream stream)
	{
		read(new BinaryReaderEx(stream));
	}

	public bool isSnappable()
	{
		LOD lOD = lods.FirstOrDefault((LOD l) => l.Resolution.getLODType() == LodName.Memory);
		if (lOD != null && lOD.NamedSelections.Where((NamedSelection ns) => ns.Name.Equals("lb", StringComparison.InvariantCultureIgnoreCase) || ns.Name.Equals("le", StringComparison.InvariantCultureIgnoreCase) || ns.Name.Equals("pb", StringComparison.InvariantCultureIgnoreCase) || ns.Name.Equals("pe", StringComparison.InvariantCultureIgnoreCase)).Count() >= 4)
		{
			return true;
		}
		return false;
	}

	private void read(BinaryReaderEx input)
	{
		string text = input.ReadAscii(4);
		if ("ODOL" != text)
		{
			throw new FormatException("ODOL signature is missing");
		}
		base.Version = input.ReadUInt32();
		if (base.Version > 73)
		{
			throw new FormatException("Unknown ODOL version");
		}
		if (base.Version < 28)
		{
			throw new FormatException("Old ODOL version is currently not supported");
		}
		input.Version = (int)base.Version;
		if (base.Version >= 44)
		{
			input.UseLZOCompression = true;
		}
		if (base.Version >= 64)
		{
			input.UseCompressionFlag = true;
		}
		if (base.Version >= 59)
		{
			appID = input.ReadUInt32();
		}
		if (base.Version >= 58)
		{
			muzzleFlash = input.ReadAsciiz();
		}
		nLods = input.ReadInt32();
		resolutions = new float[nLods];
		for (int i = 0; i < nLods; i++)
		{
			resolutions[i] = input.ReadSingle();
		}
		modelInfo = new ODOL_ModelInfo(input, nLods);
		if (base.Version >= 30)
		{
			hasAnims = input.ReadBoolean();
			if (hasAnims)
			{
				animations.read(input);
			}
		}
		lodStartAdresses = new uint[nLods];
		lodEndAdresses = new uint[nLods];
		permanent = new bool[nLods];
		for (int j = 0; j < nLods; j++)
		{
			lodStartAdresses[j] = input.ReadUInt32();
		}
		for (int k = 0; k < nLods; k++)
		{
			lodEndAdresses[k] = input.ReadUInt32();
		}
		for (int l = 0; l < nLods; l++)
		{
			permanent[l] = input.ReadBoolean();
		}
		LoadableLodInfos = new List<LoadableLodInfo>(nLods);
		lods = new LOD[nLods];
		long position = input.Position;
		for (int m = 0; m < nLods; m++)
		{
			if (!permanent[m])
			{
				LoadableLodInfo loadableLodInfo = new LoadableLodInfo();
				loadableLodInfo.ReadObject(input);
				LoadableLodInfos.Add(loadableLodInfo);
				position = input.Position;
			}
			input.Position = lodStartAdresses[m];
			lods[m] = new LOD();
			lods[m].read(input, resolutions[m]);
			input.Position = position;
		}
		input.Position = lodEndAdresses.Max();
		input.Close();
	}

	public string[] getModelCfg()
	{
		throw new NotImplementedException();
	}
}
