# GameTerrainTools (GTT) - Fixes für QGIS 3.44 / DayZ 1.29

## Problem 1 - Roadmap / OSM: HTTP → HTTPS
**Datei:** `gtt/osm/downloader.py`

Die Overpass API hat auf HTTPS-only umgestellt. Python 3 blockiert HTTP→HTTPS Redirects.

```python
# Vorher (kaputt):
"http://overpass-api.de/api/interpreter"

# Nachher (fix):
"https://overpass-api.de/api/interpreter"
```

---

## Problem 2 - Roadmap / OSM: HTTP 406 Not Acceptable
**Datei:** `gtt/osm/downloader.py`

Die Overpass API erwartet die Query als Form-Parameter (`data=<query>`) mit
`Content-Type: application/x-www-form-urlencoded` — nicht als raw XML Body.
Ausserdem blockiert die API den Standard Python User-Agent.

```python
def set_request(self, url, xml):
    if isinstance(xml, bytes):
        xml_str = xml.decode("utf-8")
    else:
        xml_str = xml
    body = urllib.parse.urlencode({"data": xml_str}).encode("utf-8")
    req = urllib.request.Request(
        url=url,
        data=body,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "QGIS-GameTerrainTools/1.1 (QGIS plugin; +https://gitlab.com/Adanteh/qgis-game-terrains)",
        },
    )
    self.request = req
    return req

def run(self):
    self.setUrllibProxy()
    try:
        response = urllib.request.urlopen(self.request)
    except urllib.error.HTTPError as e:
        # HTTPError MUSS vor URLError gefangen werden (ist eine Unterklasse)
        self.error = f"Error occurred: HTTP {e.code} Reason: {e.msg}"
        self.error_data = e
        return False
    except urllib.error.URLError as e:
        self.error = f"Error occurred: {e.args} Reason: {e.reason}"
        self.error_data = e
        return False
```

---

## Problem 3 - Heightmap / SRTM: NASA → Copernicus GLO-30
**Datei:** `gtt/heightmap/srtm.py`

NASA hat 2023 die EarthData-Authentifizierung von Basic Auth auf OAuth umgestellt.
Das Addon konnte sich nicht mehr einloggen.

**Ersatz:** Copernicus GLO-30 DEM (AWS S3, öffentlich, kein Login nötig)
- Gleiche Auflösung wie SRTM (~30m)
- Bessere Qualität (keine Radar-Artefakte)
- Direkt als GeoTIFF, kein Entpacken nötig
- Der Key bleibt `"srtm"` damit bestehende Einstellungen weiter funktionieren

Tile URL Format:
```
https://copernicus-dem-30m.s3.amazonaws.com/
  Copernicus_DSM_COG_10_N47_00_E008_00_DEM/
    Copernicus_DSM_COG_10_N47_00_E008_00_DEM.tif
```

---

## Problem 4 - QGIS 3.44 Crash: Race Condition beim Export
**Datei:** `gtt/exporter/satmap.py`

`taskCompleted` feuerte bevor der Background-Thread `exportToImage` fertig war.
Sofort danach startete der Heightmap-Export → Access Violation → Crash.

```python
# In _next(): Delay von 2.5 Sekunden nach letztem Tile
except StopIteration:
    self.output = self.mergeTiles()
    QTimer.singleShot(2500, self._done)
```

---

## Problem 5 - QGIS 3.44 Crash: Heightmap Export
**Datei:** `gtt/exporter/heightmap.py`

`iface.gtt.context` und `iface.gtt.feedback` werden nach dem ersten Aufruf
ungültig → Access Violation.

```python
def add_task(self, alg, parameters, add):
    alg = QgsApplication.processingRegistry().algorithmById(alg)
    # Frische Instanzen bei jedem Aufruf erstellen:
    self._context = QgsProcessingContext()
    self._feedback = QgsProcessingFeedback()
    self.task = QgsProcessingAlgRunnerTask(alg, parameters, self._context, self._feedback)
```

---

## Installation
1. `gtt` Ordner in QGIS Plugin-Ordner kopieren:
   `C:\Users\<name>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\gtt\`
2. `__pycache__` Ordner in `gtt/osm/` und `gtt/exporter/` löschen
3. QGIS Plugin neu laden
