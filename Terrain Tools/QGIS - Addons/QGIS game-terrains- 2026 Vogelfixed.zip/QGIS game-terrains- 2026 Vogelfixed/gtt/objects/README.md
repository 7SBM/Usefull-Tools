All this stuff is currently not accesible. 
It was never finished, is defnitely not easy to use, and not maintained in forever.