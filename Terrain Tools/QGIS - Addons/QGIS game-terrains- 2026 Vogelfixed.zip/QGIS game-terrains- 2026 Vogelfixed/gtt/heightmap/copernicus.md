coordinate system

EPSG:3035
https://land.copernicus.eu/imagery-in-situ/eu-dem/eu-dem-v1.1?tab=download
https://land.copernicus.eu/land-files/e9dfafde564580c4c627932756d5d241d23a85ba.zip


http://published-files.eea.europa.eu/eudem/entr_r_4258_1_arcsec_gsgrda-eudem-dem-europe_2012_rev1/eudem_tiles_5deg/eudem_dem_5deg_n50e015.tif
http://published-files.eea.europa.eu/eudem/entr_r_4258_1_arcsec_gsgrda-eudem-dem-europe_2012_rev1/eudem_tiles_5deg/eudem_dem_5deg_n50e015.tif