"""
Copernicus GLO-30 DEM – replacement for the old NASA SRTM source.

NASA EarthData dropped Basic-Auth in 2023, so the original SRTM download
no longer works.  The Copernicus GLO-30 DEM is a direct drop-in:
  * same 1 arc-second (~30 m) resolution
  * freely hosted on AWS S3 – no login required
  * GeoTIFF format, QGIS reads it natively

Tile URL pattern:
  https://copernicus-dem-30m.s3.amazonaws.com/
    Copernicus_DSM_COG_10_N47_00_E008_00_DEM/
      Copernicus_DSM_COG_10_N47_00_E008_00_DEM.tif
"""

import math
from pathlib import Path

from .source import HeightmapSource, register_heightmap
from gtt.extent import transform_extent
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gtt.downloader import Download


@register_heightmap
class SrtmHeightmap(HeightmapSource):
    """Downloads Copernicus GLO-30 DEM tiles (successor to NASA SRTM)."""

    BASEURL = "https://copernicus-dem-30m.s3.amazonaws.com/"
    NAME = "srtm"  # keep key "srtm" so existing UI / settings still work

    def download(self, downloader: "Download"):
        """Downloads GLO-30 tiles for the current marked extent."""
        tiles = self.find_tiles()
        if not tiles:
            return False

        for filename, url in tiles:
            file = self.get_folder("copernicus") / filename
            if not Path(file).exists():
                # No credentials needed – public S3 bucket.
                # cleanup=False: file is a GeoTIFF, not a zip.
                downloader.get_file(url, str(file), cleanup=False)
            else:
                downloader.done.emit(str(file))

        return True

    def find_tiles(self):
        """
        Returns list of (filename, url) tuples for the selected extent.
        One 1deg x 1deg tile per grid cell (lower-left corner convention).
        """
        bounds = transform_extent(targetcrs="EPSG:4326")
        left   = int(math.floor(bounds[0]))
        bottom = int(math.floor(bounds[1]))
        right  = int(math.ceil(bounds[2]))
        top    = int(math.ceil(bounds[3]))

        tiles = []
        for lat in range(bottom, top):
            for lon in range(left, right):
                ns = "N" if lat >= 0 else "S"
                ew = "E" if lon >= 0 else "W"
                lat_abs = abs(lat)
                lon_abs = abs(lon)

                basename = (
                    f"Copernicus_DSM_COG_10"
                    f"_{ns}{lat_abs:02d}_00"
                    f"_{ew}{lon_abs:03d}_00_DEM"
                )
                filename = f"{basename}.tif"
                url = f"{self.BASEURL}{basename}/{filename}"
                tiles.append((filename, url))

        return tiles

    def available(self):
        return True
