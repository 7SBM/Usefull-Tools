SETTINGSNAME = "GameTerrainTools"
PROJECT_ID = 11439079
PROJECT_URL = "https://gitlab.com/Adanteh/qgis-game-terrains/wikis/home"
