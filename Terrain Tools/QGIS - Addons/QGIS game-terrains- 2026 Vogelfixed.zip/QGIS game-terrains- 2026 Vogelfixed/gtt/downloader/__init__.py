import os
import time
import zipfile
from pathlib import Path
from types import SimpleNamespace

from qgis.utils import iface
from qgis.core import Qgis
from PyQt5.QtCore import QUrl, Qt, QFileInfo, QSettings, pyqtSignal, QObject
from PyQt5.QtWidgets import QApplication
from PyQt5.QtNetwork import QNetworkRequest, QNetworkReply, QNetworkAccessManager

from gtt.functions import message_log
from gtt.static import SETTINGSNAME
from .login_ui import LoginDialog, LoginManager
from .unzip import unzip
from .progress import ProgressBar


class Download(QObject):
    """
        Generic http downloader using QNetworkAccessManager, supports login
    """
    replied = pyqtSignal(object)
    reply = pyqtSignal(object)

    done = pyqtSignal(str)  # Download done. Called with path to file
    cancel = pyqtSignal()  #  Download cancelled
    error = pyqtSignal(str, str)  # Error title, error message
    progress = pyqtSignal(float)  # Progres in percentage


    def __init__(self):
        super().__init__(parent=iface)
        self.request_is_aborted = False
        self.network = QNetworkAccessManager()
        self.network.authenticationRequired.connect(self._set_credentials)
        self.network.finished.connect(self._reply_finished)

        self.login = LoginManager(SETTINGSNAME)
        self.file_requests = {}

    def get_file(
        self, url: str, filename: str, location: Path = None, credentials=(), cleanup=True, callback=None,
    ):
        """
        Will download a file from given URL, to target 'filename' path.
        If location path is given, it will attempt to unzip the file to the target path
        
        Args:
            url (str): URL to download file from
            filename (str): Path to download file to
            location (Path, optional): Will unzip to given path if given, Defaults to own folder
            credentials (tuple, optional): Tuple with download credentials in order:
                settings_tag, source name, registration link 
            cleanup (bool): Will cleanup zip if we unpacked it
        """

        self.request_is_aborted = False
        if credentials:
            self.login.set_credentials_info(*credentials)
        else:
            self.login.reset()

        self.progress_bar = ProgressBar()
        self.done.connect(self.progress_bar.done)
        self.cancel.connect(self.progress_bar.cancel)
        self.error.connect(self.progress_bar.error)
        self.progress.connect(self.progress_bar.progress)


        message_log(f"Download from {url}")
        qurl = QUrl(url)
        request = QNetworkRequest(qurl)

        # Object, to keep track of metadata for this get.
        data = SimpleNamespace()
        data.filename = str(filename)
        data.url = url
        data.progress = 0
        data.location = location
        data.cleanup = cleanup
        data.callback = callback

        self.file_requests[url] = data
        request = self.network.get(request)
        self.hook_progress(request, data)

    def _set_credentials(self, reply: QNetworkReply, authenticator: QNetworkAccessManager):
        """Passes login data to QNetworkAccessManager
        
        Args:
            reply (QNetworkReply): network reply requesting login info
            authenticator (QNetworkAccessManager): network access manager to send info with
        """
        if not self.request_is_aborted:
            if self.login.username and self.login.password:
                authenticator.setUser(self.login.username)
                authenticator.setPassword(self.login.password)
                return

            accept, username, password = self.login.show_ui()
            if accept:
                authenticator.setUser(username)
                authenticator.setPassword(password)
                return

        self.request_is_aborted = True
        self.cancel.emit()
        reply.abort()

    def _progress(self, bytes_read, bytes_total, data):
        if not bytes_total:
            bytes_total = 1  # Fix for some cases where bytes_total might give us 0

        # print(bytes_read, bytes_total, data)
        data.progress = bytes_read / bytes_total * 100
        total_progress = sum([request.progress for request in self.file_requests.values()]) / len(self.file_requests)
        self.progress.emit(total_progress)

    def hook_progress(self, result, data):
        result.downloadProgress.connect(lambda b_read, b_total, reply=result: self._progress(b_read, b_total, data))

    def _reply_finished(self, reply: QNetworkReply):
        """
            Reply is finished
        """
        if reply != None:
            redirect_url = reply.attribute(QNetworkRequest.RedirectionTargetAttribute)

            # If the URL is not empty, we're being redirected.
            url = reply.request().url().toString()
            data = self.file_requests[url]

            if redirect_url != None:
                request = QNetworkRequest(redirect_url)

                # Replace namespace by updated URL
                data.url = redirect_url.toString()
                self.file_requests[redirect_url.toString()] = data

                del self.file_requests[url]
                result = self.network.get(request)
                self.hook_progress(result, data)
            else:
                if reply.error() != None:
                    if reply.error() == QNetworkReply.ContentNotFoundError:
                        reply.abort()
                        reply.deleteLater()
                        self.error.emit("DOWNLOAD FAILED", "File not found on URL")
                        del self.file_requests[url]

                    elif reply.error() == QNetworkReply.NoError:
                        result = reply.readAll()
                        try:
                            f = open(data.filename, "wb")
                            f.write(result)
                            f.close()
                            del self.file_requests[url]
                            unpacked_file = unzip(data.filename, data.location, data.cleanup)
                            if unpacked_file is None:
                                self.error.emit("UNPACK ERROR", f"Failed to unpack {data.filename}")
                                return None

                            if data.callback is not None:
                                result = data.callback(data.filename, unpacked_file)
                                if result is not None:
                                    unpacked_file = result

                            self.done.emit(unpacked_file)

                        except OSError:
                            drive = Path(data.filename).drive
                            self.error.emit("DOWNLOAD FAILED", f"OS Error, Drive '{drive}' full?")
                            return

                        reply.deleteLater()
