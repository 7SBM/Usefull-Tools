

Make MR :3


# Dev environment
* QGIS development is a pain to get all the autocompletes and linting to work. Run this:

```
python .\tools\create-qgis-venv.py 
```