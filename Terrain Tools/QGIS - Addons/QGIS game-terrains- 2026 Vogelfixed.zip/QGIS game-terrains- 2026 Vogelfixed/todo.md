
# Enfusion support

<!-- * Change satmap export to .png -->
<!-- * Remove adjustments of mapframe (Projection and mapframe offset) -->
<!-- * Log min/max height to it can be used for imports -->
<!-- * Write the new stuff to the gtt_export.txt -->
* Record video on using GTT files

## Enfusion support for terrain tools
